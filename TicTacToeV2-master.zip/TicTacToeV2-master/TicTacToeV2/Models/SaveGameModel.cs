﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
namespace TicTacToeV2.Models
{
    public class SaveGameModel
    {
        public const string DataFilePath = "Data\\PlayerHistory.txt";
        public const char Delineator = ',';
    }
}